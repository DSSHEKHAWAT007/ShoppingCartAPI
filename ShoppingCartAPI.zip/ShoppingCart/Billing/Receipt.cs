﻿using ShoppingCart.Products;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Billing
{
	public class Receipt
	{
        private List<Product> ProductList { get; set; }
        private double TotalSalesTax { get; set; }
        private double TotalAmount { get; set; }

        public Receipt(List<Product> prod, double tax, double amount)
        {
            ProductList = prod;
            TotalSalesTax = tax;
            TotalAmount = amount;
        }

        public int GetTotalNumberOfItems()
        {
            return ProductList.Count;
        }

        public override string ToString()
        {
            String receipt = "";
            foreach ( var p in ProductList )
            {
                receipt += (p.ToString() + "<br/>");
            }

            receipt += "Total sales tax = " + TotalSalesTax + "<br/>";
            receipt += "Total amount = " + TotalAmount + "<br/>";

            return receipt;
        }
    }
}
