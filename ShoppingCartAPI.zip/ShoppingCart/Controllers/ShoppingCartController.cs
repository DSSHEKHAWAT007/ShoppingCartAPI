﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ShoppingCart.Billing;
using ShoppingCart.Products;
using ShoppingCart.Shopping;


namespace ShoppingCart.Controllers
{
    [EnableCors("CorsApi")]
    [Route("api/[controller]")]
    [ApiController]
    public class ShoppingCartController : ControllerBase
    {
        // POST: api/ShoppingCart
        /// <summary>
        /// /return receipt with cost,tax and details
        /// </summary>
        /// <param name="shop"></param>
        /// <returns></returns>
        [HttpPost("SaveDetails")]   
        public List<Product> SaveProducts([FromBody]Shop shop)
        {
            List<Product> products = new List<Product>();
            ShoppingStore store = new ShoppingStore();
            store.GetSalesOrder(shop.Name, shop.Price, shop.IsImported, shop.Quantity);
            products = store.CheckOut();
            return products;
        }
      
    }
}
