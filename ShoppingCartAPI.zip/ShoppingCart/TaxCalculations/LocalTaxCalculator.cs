﻿using ShoppingCart.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.TaxCalculations
{
	public class LocalTaxCalculator : ITaxCalculator
	{
		/// <summary>
		///  calculate local tax
		/// </summary>
		/// <param name="price"></param>
		/// <param name="tax"></param>
		/// <param name="imported"></param>
		/// <returns></returns>
		public double CalculateTax(double price, double localTax, bool imported)
		{
			double tax = price * localTax;

			if ( imported )
				tax += (price * 0.5);

			//rounds off to nearest 0.05;
			tax = TaxUtils.RoundOff(tax);

			return tax;
		}
	}
}
