﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.TaxCalculations
{
	public class LocalTaxValues
	{
		public static double BOOK_TAX = 0.0;
		public static double FOOD_TAX = 0.0;
		public static double MEDICAL_TAX = 0.0;
		public static double MISC_TAX = 0.10;
	}
}
