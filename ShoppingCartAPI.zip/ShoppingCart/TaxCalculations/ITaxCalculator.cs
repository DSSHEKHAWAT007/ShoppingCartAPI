﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.TaxCalculations
{
	public interface ITaxCalculator
	{
		/// <summary>
		/// / calculate tax
		/// </summary>
		/// <param name="price"></param>
		/// <param name="tax"></param>
		/// <param name="imported"></param>
		/// <returns></returns>
		double CalculateTax(double price, double tax, bool imported);
	}
}
