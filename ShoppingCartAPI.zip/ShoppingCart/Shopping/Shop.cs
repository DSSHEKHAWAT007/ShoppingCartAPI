﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ShoppingCart.Shopping
{
	public class Shop
	{
		public string Name { get; set; }

		public double Price { get; set; }

		public bool IsImported { get; set; }

		public int Quantity { get; set; }

	}
}
