﻿using ShoppingCart.Billing;
using ShoppingCart.Products;
using ShoppingCart.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoppingCart.Shopping
{
	public class ShoppingStore
	{
		private ShoppingCarts shoppingCarts;
		private StoreShelf storeShelf;
		private PaymentCounter paymentCounter;
		private string country;

		public ShoppingStore()
		{
			country = "Local";
			shoppingCarts = new ShoppingCarts();
			paymentCounter = new PaymentCounter(country);
			storeShelf = new StoreShelf();
		}

		public void RetrieveOrderAndPlaceInCart(String name, double price, bool imported, int quantity)
		{
			Product product = storeShelf.SearchAndRetrieveItemFromShelf(name, price, imported, quantity);
			shoppingCarts.AddItemToCart(product);
		}

		public void GetSalesOrder(string name, double price, bool imported, int quantity)
		{

				name = GetProductName(name);
				price = GetProductPrice(price);
				imported = IsProductImported(imported);
				quantity = GetQuantity(quantity);
				RetrieveOrderAndPlaceInCart(name, price, imported, quantity);
		}

		public List<Product> CheckOut()
		{
			List<Product> products = new List<Product>();
			products = paymentCounter.BillItemsInCart(shoppingCarts);
			Receipt receipt = paymentCounter.GetReceipt();
			return products;
		}

		public String GetProductName(string name)
		{
			return name;

		}

		public double GetProductPrice(double price)
		{
			return price;
		}

		public bool IsProductImported(bool imported)
		{

			return imported;
		}
		public int GetQuantity(int quantity)
		{

			return quantity;
		}

		public bool IsAddAnotherProduct(bool anotherproduct)
		{
			return anotherproduct;
		}
	}
}
